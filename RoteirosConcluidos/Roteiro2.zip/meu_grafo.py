from bibgrafo.grafo_lista_adjacencia import GrafoListaAdjacencia
from bibgrafo.grafo_exceptions import *
from copy import deepcopy

class MeuGrafo(GrafoListaAdjacencia):

    def grafoEmMatriz(self):
        """
        Grafo construido em formato de matriz. Ex: [['a1','J','C'],['a2',...
        :return: Grafo em matriz. Ex: [['a1','J','C'],['a2',...
        """
        grafoMatriz = []
        for i in self.A:
                grafoMatriz.append([i, self.A[i].getV1(), self.A[i].getV2()])

        return grafoMatriz

    def paresVertices(self):
        '''
        Provê uma lista de todas as combinacoes existentes no grafo.
        :return: Uma lista com os pares de vértices adjacentes
        '''
        # Lista com os pares de vértices ligados por arestas existentes
        combinacoesExistentes = []
        for i in self.A:
            combinacoesExistentes.append(self.A[i].getV1() + "-" + self.A[i].getV2())

        return combinacoesExistentes

    def pegarRotulo(self, verticeA, verticeB):
        '''
        Descobre o rotulo de determinado par de vertices.
        :return: Rotulo de um par de vertices
        :raises: VerticeInvalidoException se o vértice não existe no grafo
        '''

        if verticeA not in self.N or verticeB not in self.N: raise VerticeInvalidoException("Vertice nao existe")

        for i in self.A:
            if verticeA == self.A[i].getV1() and verticeB == self.A[i].getV2() or \
                verticeB == self.A[i].getV1() and verticeA == self.A[i].getV2():
                return self.getAresta(i).getRotulo()

        return "Erro: Combinacao inexistente"

    def vertices_nao_adjacentes(self):
        '''
        Provê uma lista de vértices não adjacentes no grafo. A lista terá o seguinte formato: [X-Z, X-W, ...]
        Onde X, Z e W são vértices no grafo que não tem uma aresta entre eles.
        :return: Uma lista com os pares de vértices não adjacentes
        '''

        combinacoesExistentes = self.paresVertices()

        # Lista com todas as combinações possíveis de pares de vértices ligados por arestas
        combinacoesPossiveis = []
        for j in self.N:
            for k in self.N:
                if j != k: # Impedindo laços
                    if (k + '-' + j) not in combinacoesPossiveis and (k + '-' + j) not in combinacoesExistentes: # Impedindo vértices iguais inversamente
                        combinacoesPossiveis.append(j + '-' + k)

        # Lista com vértices não adjacentes
        verticesNaoAdjacentes = []
        for l in combinacoesPossiveis:
            if l not in combinacoesExistentes:
                verticesNaoAdjacentes.append(l)

        return verticesNaoAdjacentes

    def ha_laco(self):
        '''
        Verifica se existe algum laço no grafo.
        :return: Um valor booleano que indica se existe algum laço.
        '''
        for i in self.A:
            if self.A[i].getV1() == self.A[i].getV2():
                return True
        return False

    def grau(self, V=''):
        '''
        Provê o grau do vértice passado como parâmetro
        :param V: O rótulo do vértice a ser analisado
        :return: Um valor inteiro que indica o grau do vértice
        :raises: VerticeInvalidoException se o vértice não existe no grafo
        '''
        if V in self.N:
            combinacoesExistentes = self.paresVertices()
            grau = 0
            for i in combinacoesExistentes:
                if i[0] == V: grau += 1
                if i[2] == V: grau += 1

            return grau
        raise VerticeInvalidoException("Vertice nao existe")

    def ha_paralelas(self):
        '''
        Verifica se há arestas paralelas no grafo
        :return: Um valor booleano que indica se existem arestas paralelas no grafo.
        '''
        combinacoesExistentes = self.paresVertices()

        for i in range(len(combinacoesExistentes)):
            for j in range(len(combinacoesExistentes)):

                if i != j :
                    if combinacoesExistentes[i] == combinacoesExistentes[j]:
                        return True
        return False

    def arestas_sobre_vertice(self, V):
        '''
        Provê uma lista que contém os rótulos das arestas que incidem sobre o vértice passado como parâmetro
        :param V: O vértice a ser analisado
        :return: Uma lista os rótulos das arestas que incidem sobre o vértice
        :raises: VerticeInvalidoException se o vértice não existe no grafo
        '''

        if V in self.N:
            listaArestasNoVertice = []
            for a in self.A:
                if self.getAresta(a).getV1() == V or self.getAresta(a).getV2() == V:
                    listaArestasNoVertice.append(self.getAresta(a).getRotulo())

            return listaArestasNoVertice
        raise VerticeInvalidoException("Vertice nao existe")

    def eh_completo(self):
        '''
        Verifica se o grafo é completo.
        :return: Um valor booleano que indica se o grafo é completo
        '''
        combinacoesExistentes = self.paresVertices()

        # Se o grafo não for simples, automaticamente não será completo.
        if self.ha_laco() or self.ha_paralelas(): return False

        # Lista com todas as combinações possíveis de pares de vértices ligados por arestas, exceto laços
        combinacoesPossiveis = []
        for j in self.N:
            for k in self.N:
                if j != k:
                    combinacoesPossiveis.append(j + '-' + k)

        soma = 0
        for l in combinacoesExistentes:
            for m in combinacoesPossiveis:
                if l == m:
                    soma += 1

        if soma == len(combinacoesPossiveis) / 2: return True
        return False

    def verticesAdjacentes(self, V=''):
        '''
        Provê uma lista de todas os vertices adjacentes a determinado vertice.
        :return: Uma lista com os vértices adjacentes possiveis.
        '''
        if V not in self.N: raise VerticeInvalidoException("Vertice nao existe")

        combinacoesExistentes = self.paresVertices()
        verticesAdjacentes = []  # Vertices que sao adjacentes

        for i in combinacoesExistentes:
            # Adicionando a lista vertices que podem servir de destino a partir do vertice que esta sendo analisado
            if i[0] == V and i[2] not in verticesAdjacentes: verticesAdjacentes.append(i[2])  # Evitando duplicidade de destino no caso de aresta paralela
            if i[2] == V and i[0] not in verticesAdjacentes: verticesAdjacentes.append(i[0])  # Evitando duplicidade de destino no caso de aresta paralela
        return verticesAdjacentes

    def dfs(self, V=''):
        '''
        Provê um grafo que contém as arestas do DFS
        :param V: O vértice onde se inicia o caminho
        :return: Um grafo do tipo árvore DFS
        :raises: VerticeInvalidoException se o vértice não existe no grafo
        '''

        if V not in self.N: raise VerticeInvalidoException("Vertice nao existe")

        listaVertices = [] # Lista que armazenara os vertices analisados
        arvoreDFS = MeuGrafo(deepcopy(self.N)) # Novo grafo que sera retornado

        # Funcao recursiva para analisar o grafo passado
        def dfsRecursiva(V=''):

            for i in range(len(self.paresVertices())):

                if V in self.paresVertices()[i]: # Se o vertice passado pertence a lista de determinado par de vertices do grafo
                    aresta = self.paresVertices()[i] # Lista que eh um par de vertice do grafo

                    if ((aresta[0] not in listaVertices) or (aresta[2] not in listaVertices) \
                            and self.paresVertices()[i][0] != self.paresVertices()[i][2]):

                        # Adicionando arestas ao novo grafo (Rotulo por meio da funcao "pegarRotulo")
                        arvoreDFS.adicionaAresta(self.pegarRotulo(aresta[0], aresta[2]), aresta[0], aresta[2])

                        listaVertices.append(aresta[0])
                        listaVertices.append(aresta[2])
                        #Chamada recursiva
                        dfsRecursiva(aresta[2] if aresta[2]!= V else aresta[0])

        dfsRecursiva(V)
        return arvoreDFS

    def bfs(self, V='', **kwargs):
        '''
        Provê um grafo que contém as arestas do BFS
        :param V: O vértice onde se inicia o caminho
        :return: Um grafo do tipo árvore BFS
        :raises: VerticeInvalidoException se o vértice não existe no grafo
        '''

        if V not in self.N: raise VerticeInvalidoException

        try:
            self.key = kwargs["bfs"]
        except:
            self.arvoreBFS = MeuGrafo(deepcopy(self.N))
            self.verticesAnalisados = []
            self.arestasIncidentes = []
            self.key = False

        for aresta in self.grafoEmMatriz():
            if (aresta[0] in self.arestas_sobre_vertice(V)) and ((aresta[1] not in self.verticesAnalisados) or \
                (aresta[2] not in self.verticesAnalisados)) and (aresta[1] != aresta[2]):

                self.arvoreBFS.adicionaAresta(aresta[0], aresta[1], aresta[2])
                self.verticesAnalisados.append(aresta[1])
                self.verticesAnalisados.append(aresta[2])

        def verificar():

            vertices = []
            for i in self.arvoreBFS.grafoEmMatriz():

                if (i[1] in vertices) == False: vertices.append(i[1])
                if (i[2] in vertices) == False: vertices.append(i[2])

            if len(vertices) == len(self.arvoreBFS.N): return True
            return False

        for aresta in self.grafoEmMatriz():
            if (aresta[0] in self.arestas_sobre_vertice(V)) and (verificar() == False) and aresta[0] not in self.arestasIncidentes:

                self.arestasIncidentes.append(aresta[0])
                self.bfs(aresta[2] if aresta[2] != V else aresta[1], **{"bfs": False})

        return self.arvoreBFS