import unittest
from meu_grafo import *
from bibgrafo.grafo_exceptions import *

class TestGrafo(unittest.TestCase):

    def setUp(self):
        # Grafo da Paraíba
        self.g_p = MeuGrafo(['J', 'C', 'E', 'P', 'M', 'T', 'Z'])
        self.g_p.adicionaAresta('a1', 'J', 'C')
        self.g_p.adicionaAresta('a2', 'C', 'E')
        self.g_p.adicionaAresta('a3', 'C', 'E')
        self.g_p.adicionaAresta('a4', 'P', 'C')
        self.g_p.adicionaAresta('a5', 'P', 'C')
        self.g_p.adicionaAresta('a6', 'T', 'C')
        self.g_p.adicionaAresta('a7', 'M', 'C')
        self.g_p.adicionaAresta('a8', 'M', 'T')
        self.g_p.adicionaAresta('a9', 'T', 'Z')

        # Grafo da Paraíba sem arestas paralelas
        self.g_p_sem_paralelas = MeuGrafo(['J', 'C', 'E', 'P', 'M', 'T', 'Z'])
        self.g_p_sem_paralelas.adicionaAresta('a1', 'J', 'C')
        self.g_p_sem_paralelas.adicionaAresta('a2', 'C', 'E')
        self.g_p_sem_paralelas.adicionaAresta('a3', 'P', 'C')
        self.g_p_sem_paralelas.adicionaAresta('a4', 'T', 'C')
        self.g_p_sem_paralelas.adicionaAresta('a5', 'M', 'C')
        self.g_p_sem_paralelas.adicionaAresta('a6', 'M', 'T')
        self.g_p_sem_paralelas.adicionaAresta('a7', 'T', 'Z')

        # Grafo Roteiro 2
        self.g_Roteiro2 = MeuGrafo(['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K'])
        self.g_Roteiro2.adicionaAresta('a1', 'A', 'B')
        self.g_Roteiro2.adicionaAresta('a2', 'A', 'G')
        self.g_Roteiro2.adicionaAresta('a3', 'A', 'J')
        self.g_Roteiro2.adicionaAresta('a4', 'K', 'G')
        self.g_Roteiro2.adicionaAresta('a5', 'K', 'J')
        self.g_Roteiro2.adicionaAresta('a6', 'J', 'G')
        self.g_Roteiro2.adicionaAresta('a7', 'J', 'I')
        self.g_Roteiro2.adicionaAresta('a8', 'G', 'I')
        self.g_Roteiro2.adicionaAresta('a9', 'G', 'H')
        self.g_Roteiro2.adicionaAresta('a10', 'H', 'F')
        self.g_Roteiro2.adicionaAresta('a11', 'F', 'B')
        self.g_Roteiro2.adicionaAresta('a12', 'B', 'G')
        self.g_Roteiro2.adicionaAresta('a13', 'B', 'C')
        self.g_Roteiro2.adicionaAresta('a14', 'C', 'D')
        self.g_Roteiro2.adicionaAresta('a15', 'D', 'E')
        self.g_Roteiro2.adicionaAresta('a16', 'D', 'B')
        self.g_Roteiro2.adicionaAresta('a17', 'B', 'E')

        # Grafos completos
        self.g_c = MeuGrafo(['J', 'C', 'E', 'P'])
        self.g_c.adicionaAresta('a1', 'J', 'C')
        self.g_c.adicionaAresta('a2', 'J', 'E')
        self.g_c.adicionaAresta('a3', 'J', 'P')
        self.g_c.adicionaAresta('a4', 'E', 'C')
        self.g_c.adicionaAresta('a5', 'P', 'C')
        self.g_c.adicionaAresta('a6', 'P', 'E')

        self.g_c2 = MeuGrafo(['Nina', 'Maria'])
        self.g_c2.adicionaAresta('amiga', 'Nina', 'Maria')

        self.g_c3 = MeuGrafo(['J'])

        # Grafos com laco
        self.g_l1 = MeuGrafo(['A', 'B', 'C', 'D'])
        self.g_l1.adicionaAresta('a1', 'A', 'A')
        self.g_l1.adicionaAresta('a2', 'A', 'B')
        self.g_l1.adicionaAresta('a3', 'A', 'A')

        self.g_l2 = MeuGrafo(['A', 'B', 'C', 'D'])
        self.g_l2.adicionaAresta('a1', 'A', 'B')
        self.g_l2.adicionaAresta('a2', 'B', 'B')
        self.g_l2.adicionaAresta('a3', 'B', 'A')

        self.g_l3 = MeuGrafo(['A', 'B', 'C', 'D'])
        self.g_l3.adicionaAresta('a1', 'C', 'A')
        self.g_l3.adicionaAresta('a2', 'C', 'C')
        self.g_l3.adicionaAresta('a3', 'D', 'D')
        self.g_l3.adicionaAresta('a4', 'D', 'D')

        self.g_l4 = MeuGrafo(['D'])
        self.g_l4.adicionaAresta('a1', 'D', 'D')

        self.g_l5 = MeuGrafo(['C', 'D'])
        self.g_l5.adicionaAresta('a1', 'D', 'C')
        self.g_l5.adicionaAresta('a2', 'C', 'C')

        # Grafos desconexos
        self.g_d = MeuGrafo(['A', 'B', 'C', 'D'])
        self.g_d.adicionaAresta('asd', 'A', 'B')

        # Grafo Paraiba DFS partindo de J
        self.g_p_DFS_J = MeuGrafo(['J', 'C', 'E', 'P', 'M', 'T', 'Z'])
        self.g_p_DFS_J.adicionaAresta('a1', 'J', 'C')
        self.g_p_DFS_J.adicionaAresta('a2', 'C', 'E')
        self.g_p_DFS_J.adicionaAresta('a4', 'P', 'C')
        self.g_p_DFS_J.adicionaAresta('a6', 'T', 'C')
        self.g_p_DFS_J.adicionaAresta('a8', 'M', 'T')
        self.g_p_DFS_J.adicionaAresta('a9', 'T', 'Z')

        # Grafo Roteiro2 DFS partindo de K
        self.g_Roteiro2_DFS_K = MeuGrafo(['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K'])
        self.g_Roteiro2_DFS_K.adicionaAresta('a4', 'K', 'G')
        self.g_Roteiro2_DFS_K.adicionaAresta('a2', 'A', 'G')
        self.g_Roteiro2_DFS_K.adicionaAresta('a1', 'A', 'B')
        self.g_Roteiro2_DFS_K.adicionaAresta('a11', 'F', 'B')
        self.g_Roteiro2_DFS_K.adicionaAresta('a10', 'H', 'F')
        self.g_Roteiro2_DFS_K.adicionaAresta('a13', 'B', 'C')
        self.g_Roteiro2_DFS_K.adicionaAresta('a14', 'C', 'D')
        self.g_Roteiro2_DFS_K.adicionaAresta('a15', 'D', 'E')
        self.g_Roteiro2_DFS_K.adicionaAresta('a3', 'A', 'J')
        self.g_Roteiro2_DFS_K.adicionaAresta('a7', 'J', 'I')

        # Grafo da Paraíba BFS partindo de C
        self.g_p_BFS_C = MeuGrafo(['J', 'C', 'E', 'P', 'M', 'T', 'Z'])
        self.g_p_BFS_C.adicionaAresta('a1', 'J', 'C')
        self.g_p_BFS_C.adicionaAresta('a2', 'C', 'E')
        self.g_p_BFS_C.adicionaAresta('a4', 'P', 'C')
        self.g_p_BFS_C.adicionaAresta('a6', 'T', 'C')
        self.g_p_BFS_C.adicionaAresta('a7', 'M', 'C')
        self.g_p_BFS_C.adicionaAresta('a9', 'T', 'Z')

        # Grafo Roteiro2 BFS partindo de F
        self.g_Roteiro2_BFS_F = MeuGrafo(['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K'])
        self.g_Roteiro2_BFS_F.adicionaAresta('a10', 'H', 'F')
        self.g_Roteiro2_BFS_F.adicionaAresta('a11', 'F', 'B')
        self.g_Roteiro2_BFS_F.adicionaAresta('a9', 'G', 'H')
        self.g_Roteiro2_BFS_F.adicionaAresta('a2', 'A', 'G')
        self.g_Roteiro2_BFS_F.adicionaAresta('a4', 'K', 'G')
        self.g_Roteiro2_BFS_F.adicionaAresta('a6', 'J', 'G')
        self.g_Roteiro2_BFS_F.adicionaAresta('a8', 'G', 'I')
        self.g_Roteiro2_BFS_F.adicionaAresta('a13', 'B', 'C')
        self.g_Roteiro2_BFS_F.adicionaAresta('a16', 'D', 'B')
        self.g_Roteiro2_BFS_F.adicionaAresta('a17', 'B', 'E')

    def test_adiciona_aresta(self):
        self.assertTrue(self.g_p.adicionaAresta('a10', 'J', 'C'))
        with self.assertRaises(ArestaInvalidaException):
            self.assertTrue(self.g_p.adicionaAresta('b1', '', 'C'))
        with self.assertRaises(ArestaInvalidaException):
            self.assertTrue(self.g_p.adicionaAresta('b1', 'A', 'C'))
        with self.assertRaises(ArestaInvalidaException):
            self.g_p.adicionaAresta('')
        with self.assertRaises(ArestaInvalidaException):
            self.g_p.adicionaAresta('aa-bb')
        with self.assertRaises(ArestaInvalidaException):
            self.g_p.adicionaAresta('x', 'J', 'V')
        with self.assertRaises(ArestaInvalidaException):
            self.g_p.adicionaAresta('a1', 'J', 'C')

    def test_vertices_nao_adjacentes(self):
        self.assertEqual(self.g_p.vertices_nao_adjacentes(), ['J-E', 'J-P', 'J-M', 'J-T', 'J-Z', 'C-Z', 'E-P', 'E-M', 'E-T', 'E-Z', 'P-M', 'P-T', 'P-Z', 'M-Z'])
        self.assertEqual(self.g_c.vertices_nao_adjacentes(), [])
        self.assertEqual(self.g_c3.vertices_nao_adjacentes(), [])

    def test_ha_laco(self):
        self.assertFalse(self.g_p.ha_laco())
        self.assertFalse(self.g_p_sem_paralelas.ha_laco())
        self.assertFalse(self.g_c2.ha_laco())
        self.assertTrue(self.g_l1.ha_laco())
        self.assertTrue(self.g_l2.ha_laco())
        self.assertTrue(self.g_l3.ha_laco())
        self.assertTrue(self.g_l4.ha_laco())
        self.assertTrue(self.g_l5.ha_laco())

    def test_grau(self):
        # Paraíba
        self.assertEqual(self.g_p.grau('J'), 1)
        self.assertEqual(self.g_p.grau('C'), 7)
        self.assertEqual(self.g_p.grau('E'), 2)
        self.assertEqual(self.g_p.grau('P'), 2)
        self.assertEqual(self.g_p.grau('M'), 2)
        self.assertEqual(self.g_p.grau('T'), 3)
        self.assertEqual(self.g_p.grau('Z'), 1)
        with self.assertRaises(VerticeInvalidoException):
            self.assertEqual(self.g_p.grau('G'), 5)

        self.assertEqual(self.g_d.grau('A'), 1)
        self.assertEqual(self.g_d.grau('C'), 0)
        self.assertNotEqual(self.g_d.grau('D'), 2)

        # Completos
        self.assertEqual(self.g_c.grau('J'), 3)
        self.assertEqual(self.g_c.grau('C'), 3)
        self.assertEqual(self.g_c.grau('E'), 3)
        self.assertEqual(self.g_c.grau('P'), 3)

        # Com laço. Lembrando que cada laço conta 2 vezes por vértice para cálculo do grau
        self.assertEqual(self.g_l1.grau('A'), 5)
        self.assertEqual(self.g_l2.grau('B'), 4)
        self.assertEqual(self.g_l4.grau('D'), 2)

    def test_ha_paralelas(self):
        self.assertTrue(self.g_p.ha_paralelas())
        self.assertFalse(self.g_p_sem_paralelas.ha_paralelas())
        self.assertFalse(self.g_c.ha_paralelas())
        self.assertFalse(self.g_c2.ha_paralelas())
        self.assertFalse(self.g_c3.ha_paralelas())
        self.assertTrue(self.g_l1.ha_paralelas())

    def test_arestas_sobre_vertice(self):
        self.assertEqual(set(self.g_p.arestas_sobre_vertice('J')), set(['a1']))
        self.assertEqual(set(self.g_p.arestas_sobre_vertice('C')), set(['a1', 'a2', 'a3', 'a4', 'a5', 'a6', 'a7']))
        self.assertEqual(set(self.g_p.arestas_sobre_vertice('M')), set(['a7', 'a8']))
        self.assertEqual(set(self.g_l2.arestas_sobre_vertice('B')), set(['a1', 'a2', 'a3']))
        self.assertEqual(set(self.g_d.arestas_sobre_vertice('C')), set())
        self.assertEqual(set(self.g_d.arestas_sobre_vertice('A')), set(['asd']))
        with self.assertRaises(VerticeInvalidoException):
            self.g_p.arestas_sobre_vertice('A')

    def test_eh_completo(self):
        self.assertFalse(self.g_p.eh_completo())
        self.assertFalse((self.g_p_sem_paralelas.eh_completo()))
        self.assertTrue((self.g_c.eh_completo()))
        self.assertTrue((self.g_c2.eh_completo()))
        self.assertTrue((self.g_c3.eh_completo()))
        self.assertFalse((self.g_l1.eh_completo()))
        self.assertFalse((self.g_l2.eh_completo()))
        self.assertFalse((self.g_l3.eh_completo()))
        self.assertFalse((self.g_l4.eh_completo()))
        self.assertFalse((self.g_l5.eh_completo()))

    def test_dfs(self):

        self.assertEqual(list(self.g_p_sem_paralelas.dfs('J').A), ['a1', 'a2', 'a3', 'a4', 'a6', 'a7'])
        self.assertEqual(list(self.g_p_sem_paralelas.dfs('C').A), ['a1', 'a2', 'a3', 'a4', 'a6', 'a7'])
        self.assertEqual(list(self.g_p_sem_paralelas.dfs('E').A), ['a2', 'a1', 'a3', 'a4', 'a6', 'a7'])
        self.assertEqual(list(self.g_p_sem_paralelas.dfs('P').A), ['a3', 'a1', 'a2', 'a4', 'a6', 'a7'])
        self.assertEqual(list(self.g_p_sem_paralelas.dfs('M').A), ['a5', 'a1', 'a2', 'a3', 'a4', 'a7'])
        self.assertEqual(list(self.g_p_sem_paralelas.dfs('T').A), ['a4', 'a1', 'a2', 'a3', 'a5', 'a7'])
        self.assertEqual(list(self.g_p_sem_paralelas.dfs('Z').A), ['a7', 'a4', 'a1', 'a2', 'a3', 'a5'])
        with self.assertRaises(VerticeInvalidoException):
            self.assertEqual(list(self.g_p_sem_paralelas.dfs('A').A), [])

        self.assertEqual(self.g_p.dfs("J"), self.g_p_DFS_J)

        self.assertEqual(self.g_Roteiro2.dfs("K"), self.g_Roteiro2_DFS_K)

        self.assertEqual(list(self.g_Roteiro2.dfs('A').A), ['a1', 'a11', 'a10', 'a9', 'a4', 'a5', 'a7', 'a13', 'a14', 'a15'])
        self.assertEqual(list(self.g_Roteiro2.dfs('B').A), ['a1', 'a2', 'a4', 'a5', 'a7', 'a9', 'a10', 'a13', 'a14', 'a15'])
        self.assertEqual(list(self.g_Roteiro2.dfs('C').A), ['a13', 'a1', 'a2', 'a4', 'a5', 'a7', 'a9', 'a10', 'a16', 'a15'])
        self.assertEqual(list(self.g_Roteiro2.dfs('D').A), ['a14', 'a13', 'a1', 'a2', 'a4', 'a5', 'a7', 'a9', 'a10', 'a17'])
        self.assertEqual(list(self.g_Roteiro2.dfs('E').A), ['a15', 'a14', 'a13', 'a1', 'a2', 'a4', 'a5', 'a7', 'a9', 'a10'])
        self.assertEqual(list(self.g_Roteiro2.dfs('F').A), ['a10', 'a9', 'a2', 'a1', 'a13', 'a14', 'a15', 'a3', 'a5', 'a7'])
        self.assertEqual(list(self.g_Roteiro2.dfs('G').A), ['a2', 'a1', 'a11', 'a10', 'a13', 'a14', 'a15', 'a3', 'a5', 'a7'])
        self.assertEqual(list(self.g_Roteiro2.dfs('H').A), ['a9', 'a2', 'a1', 'a11', 'a13', 'a14', 'a15', 'a3', 'a5', 'a7'])
        self.assertEqual(list(self.g_Roteiro2.dfs('I').A), ['a7', 'a3', 'a1', 'a11', 'a10', 'a9', 'a4', 'a13', 'a14', 'a15'])
        self.assertEqual(list(self.g_Roteiro2.dfs('J').A), ['a3', 'a1', 'a11', 'a10', 'a9', 'a4', 'a8', 'a13', 'a14', 'a15'])
        self.assertEqual(list(self.g_Roteiro2.dfs('K').A), ['a4', 'a2', 'a1', 'a11', 'a10', 'a13', 'a14', 'a15', 'a3', 'a7'])
        with self.assertRaises(VerticeInvalidoException):
            self.assertEqual(list(self.g_Roteiro2.dfs('X').A), [])

    def test_bfs(self):
        self.assertEqual(list(self.g_p.bfs('J').A),['a1', 'a2', 'a4', 'a6', 'a7', 'a9'])
        self.assertEqual(list(self.g_p.bfs('C').A),['a1', 'a2', 'a4', 'a6', 'a7', 'a9'])
        self.assertEqual(list(self.g_p.bfs('E').A),['a2', 'a1', 'a4', 'a6', 'a7', 'a9'])
        self.assertEqual(list(self.g_p.bfs('P').A),['a4', 'a1', 'a2', 'a6', 'a7', 'a9'])
        self.assertEqual(list(self.g_p.bfs('M').A),['a7', 'a8', 'a1', 'a2', 'a4', 'a9'])
        self.assertEqual(list(self.g_p.bfs('T').A),['a6', 'a8', 'a9', 'a1', 'a2', 'a4'])
        self.assertEqual(list(self.g_p.bfs('Z').A),['a9', 'a6', 'a8', 'a1', 'a2', 'a4'])
        with self.assertRaises(VerticeInvalidoException):
            self.assertEqual(list(self.g_p.dfs('A').A), [])

        self.assertEqual(self.g_p.bfs("C"), self.g_p_BFS_C)

        self.assertEqual(self.g_Roteiro2.bfs("F"), self.g_Roteiro2_BFS_F)

        self.assertEqual(list(self.g_Roteiro2.bfs('A').A),['a1', 'a2', 'a3', 'a11', 'a13', 'a16', 'a17', 'a10', 'a4', 'a8'])
        self.assertEqual(list(self.g_Roteiro2.bfs('B').A),['a1', 'a11', 'a12', 'a13', 'a16', 'a17', 'a3', 'a4', 'a8', 'a9'])
        self.assertEqual(list(self.g_Roteiro2.bfs('C').A),['a13', 'a14', 'a1', 'a11', 'a12', 'a17', 'a3', 'a4', 'a8', 'a9'])
        self.assertEqual(list(self.g_Roteiro2.bfs('D').A),['a14', 'a15', 'a16', 'a1', 'a11', 'a12', 'a3', 'a4', 'a8', 'a9'])
        self.assertEqual(list(self.g_Roteiro2.bfs('E').A),['a15', 'a17', 'a14', 'a1', 'a11', 'a12', 'a3', 'a4', 'a8', 'a9'])
        self.assertEqual(list(self.g_Roteiro2.bfs('F').A),['a10', 'a11', 'a9', 'a2', 'a4', 'a6', 'a8', 'a13', 'a16', 'a17'])
        self.assertEqual(list(self.g_Roteiro2.bfs('G').A),['a2', 'a4', 'a6', 'a8', 'a9', 'a12', 'a11', 'a13', 'a16', 'a17'])
        self.assertEqual(list(self.g_Roteiro2.bfs('H').A),['a9', 'a10', 'a2', 'a4', 'a6', 'a8', 'a12', 'a13', 'a16', 'a17'])
        self.assertEqual(list(self.g_Roteiro2.bfs('I').A),['a7', 'a8', 'a3', 'a5', 'a1', 'a11', 'a13', 'a16', 'a17', 'a10'])
        self.assertEqual(list(self.g_Roteiro2.bfs('J').A),['a3', 'a5', 'a6', 'a7', 'a1', 'a11', 'a13', 'a16', 'a17', 'a10'])
        self.assertEqual(list(self.g_Roteiro2.bfs('K').A),['a4', 'a5', 'a2', 'a8', 'a9', 'a12', 'a11', 'a13', 'a16', 'a17'])
        with self.assertRaises(VerticeInvalidoException):
            self.assertEqual(list(self.g_Roteiro2.bfs('X').A), [])