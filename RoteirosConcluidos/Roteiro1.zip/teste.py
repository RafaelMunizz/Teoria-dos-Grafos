from bibgrafo.grafo_lista_adjacencia import GrafoListaAdjacencia
from bibgrafo.grafo_exceptions import *
from meu_grafo import MeuGrafo

# SIMPLES / NÃO COMPLETO
grafoTest1 = MeuGrafo(['A', 'B', 'C', 'D', 'E'])
grafoTest1.adicionaAresta('a1', 'A', 'B')
grafoTest1.adicionaAresta('a2', 'B', 'D')
grafoTest1.adicionaAresta('a3', 'B', 'C')
grafoTest1.adicionaAresta('a4', 'C', 'D')
grafoTest1.adicionaAresta('a5', 'D', 'E')
grafoTest1.adicionaAresta('a6', 'C', 'E')

# LAÇO
grafoTest2 = MeuGrafo(['A', 'B', 'C', 'D'])
grafoTest2.adicionaAresta('a1', 'A', 'B')
grafoTest2.adicionaAresta('a2', 'A', 'C')
grafoTest2.adicionaAresta('a3', 'B', 'C')
grafoTest2.adicionaAresta('a4', 'B', 'D')
grafoTest2.adicionaAresta('a5', 'D', 'D')

# SIMPLES / NÃO COMPLETO
grafoTest3 = MeuGrafo(['M', 'N', 'O', 'P', 'Q'])
grafoTest3.adicionaAresta('a1', 'M', 'O')
grafoTest3.adicionaAresta('a2', 'M', 'P')
grafoTest3.adicionaAresta('a3', 'O', 'N')
grafoTest3.adicionaAresta('a4', 'N', 'P')
grafoTest3.adicionaAresta('a5', 'P', 'Q')

# SIMPLES / NÃO COMPLETO
grafoTest4 = MeuGrafo(['1', '2', '3', '4', '5', '6'])
grafoTest4.adicionaAresta('a1', '1', '2')
grafoTest4.adicionaAresta('a2', '1', '3')
grafoTest4.adicionaAresta('a3', '1', '4')
grafoTest4.adicionaAresta('a4', '1', '6')
grafoTest4.adicionaAresta('a5', '3', '4')
grafoTest4.adicionaAresta('a6', '3', '5')
grafoTest4.adicionaAresta('a7', '4', '5')
grafoTest4.adicionaAresta('a8', '2', '3')
grafoTest4.adicionaAresta('a9', '2', '5')
grafoTest4.adicionaAresta('a10', '5', '6')
grafoTest4.adicionaAresta('a11', '4', '6')
grafoTest4.adicionaAresta('a12', '2', '6')

# BIPARTIDO
grafoTest5 = MeuGrafo(['1', '2', '3', '4', '5', '6'])
grafoTest5.adicionaAresta('a1', '1', '4')
grafoTest5.adicionaAresta('a2', '1', '5')
grafoTest5.adicionaAresta('a3', '1', '6')
grafoTest5.adicionaAresta('a4', '2', '4')
grafoTest5.adicionaAresta('a5', '2', '5')
grafoTest5.adicionaAresta('a6', '2', '6')
grafoTest5.adicionaAresta('a7', '3', '4')
grafoTest5.adicionaAresta('a8', '3', '5')
grafoTest5.adicionaAresta('a9', '3', '6')

# COMPLETO
grafoTest6 = MeuGrafo(['P', 'Q', 'R', 'S', 'T'])
grafoTest6.adicionaAresta('a1', 'P', 'T')
grafoTest6.adicionaAresta('a2', 'P', 'S')
grafoTest6.adicionaAresta('a3', 'P', 'R')
grafoTest6.adicionaAresta('a4', 'P', 'Q')
grafoTest6.adicionaAresta('a5', 'Q', 'T')
grafoTest6.adicionaAresta('a6', 'R', 'T')
grafoTest6.adicionaAresta('a7', 'Q', 'S')
grafoTest6.adicionaAresta('a8', 'Q', 'R')
grafoTest6.adicionaAresta('a9', 'R', 'S')
grafoTest6.adicionaAresta('a10', 'S', 'T')

# LAÇO / AR. PARALELAS
grafoTest7 = MeuGrafo(['A', 'B', 'C', 'D', 'E'])
grafoTest7.adicionaAresta('a1', 'A', 'B')
grafoTest7.adicionaAresta('a2', 'A', 'B')
grafoTest7.adicionaAresta('a3', 'A', 'E')
grafoTest7.adicionaAresta('a4', 'E', 'E')
grafoTest7.adicionaAresta('a5', 'B', 'D')
grafoTest7.adicionaAresta('a6', 'D', 'C')

# AR. PARALELAS
grafoTest8 = MeuGrafo(['1', '2', '3', '4'])
grafoTest8.adicionaAresta('a1', '1', '2')
grafoTest8.adicionaAresta('a2', '2', '3')
grafoTest8.adicionaAresta('a3', '2', '3')
grafoTest8.adicionaAresta('a4', '3', '4')
