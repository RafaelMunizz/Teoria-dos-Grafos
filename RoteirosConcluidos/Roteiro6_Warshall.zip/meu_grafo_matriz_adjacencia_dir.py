from bibgrafo.grafo_matriz_adj_dir import GrafoMatrizAdjacenciaDirecionado
from bibgrafo.grafo_exceptions import *
from copy import deepcopy

class MeuGrafo(GrafoMatrizAdjacenciaDirecionado):

    def modificarMatriz(self, grafo):
        '''
        Modifica o grafo para que ele se transforme em uma matriz composta apenas de 1 e 0.
        :param grafo: O grafo que será transformado.
        :return: Uma matriz. Ex: [[1, 0, 0, 1], [0, 0, 0, 1], [1, 0, 0, 0], [0, 1, 0, 0]]
        '''

        matriz = []

        for i in range(len(grafo.M)):
            aux = []
            for j in range(len(grafo.M[0])):

                if grafo.M[i][j]:
                    aux.append(1)
                else:
                    aux.append(0)

            matriz.append(aux)

        return matriz

    def warshall(self):
        '''
        Utiliza o algoritmo de warshall para criar uma matriz formada de 1 e 0 com base em uma matriz inicial.
        :param : O grafo.
        :return: A matriz alcançabilidade formada por 0 e 1. Ex: [[1, 1, 0, 1], [0, 1, 0, 1], [1, 1, 0, 1], [0, 1, 0, 1]]
        '''

        matrizAlcancabilidade = self.modificarMatriz(deepcopy(self))

        for i in range(len(self.N)):
            for j in range(len(self.N)):

                if matrizAlcancabilidade[j][i] == 1:

                    for k in range(len(self.N)):

                        matrizAlcancabilidade[j][k] = max(matrizAlcancabilidade[j][k], matrizAlcancabilidade[i][k])

        return matrizAlcancabilidade

    def imprimirMatriz(self, matriz):
        '''
        imprime o grafo de uma forma mais visível para o usuário.
        :param matriz: Uma matriz formada por 0 e 1.
        Ex:
        :entrada: [[1, 1, 0, 1], [0, 1, 0, 1], [1, 1, 0, 1], [0, 1, 0, 1]].
        :saída:  |A|B|C|D|
                A|1 1 0 1
                B|0 1 0 1
                C|1 1 0 1
                D|0 1 0 1
        '''

        print(" ",end='|')
        for k in range(len(self.N)):
            print(self.N[k], end='|')
        print()

        for i in range(len(matriz)):
            print(self.N[i], end='|')

            for j in range(len(matriz[0])):
                print(matriz[i][j], end=' ')

            print()
