from bibgrafo.grafo_matriz_adj_nao_dir import GrafoMatrizAdjacenciaNaoDirecionado
from bibgrafo.grafo_exceptions import *

class MeuGrafo(GrafoMatrizAdjacenciaNaoDirecionado):

    def vertices_nao_adjacentes(self):
        '''
        Provê uma lista de vértices não adjacentes no grafo. A lista terá o seguinte formato: [X-Z, X-W, ...]
        Onde X, Z e W são vértices no grafo que não tem uma aresta entre eles.
        :return: Uma lista com os pares de vértices não adjacentes
        '''

        lista = []
        for i in range(len(self.M)):
            for j in range(len(self.M)):

                if self.M[i][j] != '-':
                    if not self.M[i][j] and i != j:

                        lista.append(self.N[i] + '-' + self.N[j])

        return lista

    def ha_laco(self):
        '''
        Verifica se existe algum laço no grafo.
        :return: Um valor booleano que indica se existe algum laço.
        '''
        for i in range(len(self.M)):
            if self.M[i][i]:
                return True
        return False

    def grau(self, V=''):
        '''
        Provê o grau do vértice passado como parâmetro
        :param V: O rótulo do vértice a ser analisado
        :return: Um valor inteiro que indica o grau do vértice
        :raises: VerticeInvalidoException se o vértice não existe no grafo
        '''
        if V not in self.N: raise VerticeInvalidoException("Vértice não existe")

        indiceVertice = self.N.index(V)
        grau = 0

        for i in range(len(self.N)):
            if self.M[indiceVertice][i] and self.M[i][indiceVertice]:

                if len(self.M[indiceVertice][i]) > 0 and self.M[indiceVertice][i] != '-': # LINHA
                    grau += len(self.M[indiceVertice][i])
                if len(self.M[i][indiceVertice]) > 0 and self.M[i][indiceVertice] != '-': # COLUNA
                    grau += len(self.M[i][indiceVertice])

        return grau

    def ha_paralelas(self):
        '''
        Verifica se há arestas paralelas no grafo
        :return: Um valor booleano que indica se existem arestas paralelas no grafo.
        '''
        for i in range(len(self.M)):
            for j in range(len(self.M[i])):

                if len(self.M[i][j]) > 1:
                    return True
        return False

    def arestas_sobre_vertice(self, V):
        '''
        Provê uma lista que contém os rótulos das arestas que incidem sobre o vértice passado como parâmetro
        :param V: O vértice a ser analisado
        :return: Uma lista os rótulos das arestas que incidem sobre o vértice
        :raises: VerticeInvalidoException se o vértice não existe no grafo
        '''

        if V not in self.N: raise VerticeInvalidoException("Vértice não existe")

        indiceVertice = self.N.index(V)

        matrizArestas = []
        for i in range(len(self.N)):
            if self.M[indiceVertice][i] and self.M[i][indiceVertice]:

                if self.M[indiceVertice][i] != '-':  # LINHA
                    matrizArestas.append(list(self.M[indiceVertice][i].keys()))
                if self.M[i][indiceVertice] != '-':  # COLUNA
                    matrizArestas.append(list(self.M[i][indiceVertice].keys()))

        arestasVertice = []
        for arestas in matrizArestas:
            for aresta in arestas:
                arestasVertice.append(aresta)

        return arestasVertice

    def eh_completo(self):
        '''
        Verifica se o grafo é completo.
        :return: Um valor booleano que indica se o grafo é completo
        '''

        for i in self.N:
            if len(self.arestas_sobre_vertice(i)) != (len(self.N) - 1):
                return False
        return True

    def dfs(self, V='', **kwargs):
        '''
        Provê uma árvore (um grafo) que contém apenas as arestas do dfs
        :param V: O vértice a de onde se inicia o caminho
        :return: Um grafo do tipo árvore
        :raises: VerticeInvalidoException se o vértice não existe no grafo
        '''
        if V not in self.N:
            raise VerticeInvalidoException

        try:
            self.acdfs = kwargs["dfs"]
        except:
            self.acdfs = True

        if self.acdfs == True:
            self._arvoredfs = MeuGrafo(self.N)
            self.arestas_dfs = []
            self.acdfs = False

        for coluna in self.M[self.N.index(V)]:
            if coluna != "-" and coluna != {}:
                for aresta in coluna:
                    if ((coluna[aresta].getV1() not in self.arestas_dfs) or (
                            coluna[aresta].getV2() not in self.arestas_dfs)) \
                            and (coluna[aresta].getV1() != coluna[aresta].getV2()):
                        self._arvoredfs.adicionaAresta(aresta, coluna[aresta].getV1(), coluna[aresta].getV2())
                        self.arestas_dfs.append(coluna[aresta].getV1())
                        self.arestas_dfs.append(coluna[aresta].getV2())
                        self.dfs(coluna[aresta].getV2() if coluna[aresta].getV2() != V else coluna[aresta].getV1(),
                                 **{"dfs": False})

        return self._arvoredfs

    def conexo(self):
        '''
        Verifica se o grafo é conexo
        :return: Bool representando se o grafo é conexo
        '''
        listadfs = list()
        dfs = self.dfs(self.N[0])
        l = list()
        for linha in self.M:
            for coluna in linha:
                if coluna != "-" and coluna != {}:
                    for aresta in coluna:
                        l.append(coluna[aresta].getV1())
                        l.append(coluna[aresta].getV2())
        listadfs.append(l)
        for dfs in listadfs:
            for vertice in self.N:
                if not (vertice in dfs):
                    return False
        return True

    def caminhoEuleriano(self):
        '''
        Verifica se o grafo possui um caminho euleriano.
        Caso possua, prove uma lista do tipo [V0,A0 .. Vn,An].
        :return: False ou lista com caminho.
        '''
        impar, lvi = self.ehEuleriano()
        if (not impar) or (not self.conexo()):
            return False

        self._caminho = list()
        self._matriz = self.matrizArestas()
        self._arestas = self.getAresta()

        # Escolhe o vertice de inicio do caminho
        if lvi != []:
            Vi = lvi[0]
        elif lvi == []:
            Vi = 0
        self._caminho.append(self.N[Vi])
        Eh_caminho = self.buscarCaminho(Vi)

        return self._caminho

    def ehEuleriano(self):
        '''
        Verifica se cada vertice é de grau impar e a quantidade
        de vertices impares no grafo
        :return: True, lista de vertices impar se verdadeiro
                 False, None se falso
        '''
        total = 0
        i = 0
        lvi = list()
        while (total <= 2) and (i <= len(self.N) - 1):
            grau = 0
            grau += self.grau(self.N[i])
            if grau % 2 == 1:
                total += 1
                lvi.append(i)
            i += 1
        if total == 0 or total == 2:
            return True, lvi
        else:
            return False, None

    def buscarCaminho(self, v):
        '''
        Gera o caminho eureliano.
        :return: bool referente a existencia do caminho.
        '''
        grau = self.grauMatriz(self.N[v], self._matriz)
        if grau == 0:
            return True
        elif grau == 1:
            for c in range(len(self.M[v])):
                if v < c:
                    linha, coluna = v, c
                else:
                    linha, coluna = c, v
                if self._arestas != [] and self._matriz[linha][coluna] != "-" and self._matriz[linha][coluna] != {}:
                    aresta = self._matriz[linha][coluna]
                    self._arestas.remove(aresta[0])
                    self._caminho.append(aresta[0])
                    self._caminho.append(aresta[1] if aresta[1] != self.N[v] else aresta[2])
                    self._matriz[linha][coluna] = "-"
                    self.buscarCaminho(self.N.index(aresta[1] if aresta[1] != self.N[v] else aresta[2]))
        else:
            __N = self.N.copy()
            for c in range(len(self.M[v])):
                if v < c:
                    linha, coluna = v, c
                else:
                    linha, coluna = c, v
                if self._arestas != [] and self._matriz[linha][coluna] != "-" and self._matriz[linha][coluna] != {}:
                    aresta = self._matriz[linha][coluna]
                    self._matriz[linha][coluna] = "-"
                    if self.grauMatriz(self.N[v], self._matriz) == 0: __N.remove(self.N[v])
                    if not self.ponte(__N):
                        self._arestas.remove(aresta[0])
                        self._caminho.append(aresta[0])
                        self._caminho.append(aresta[1] if aresta[1] != self.N[v] else aresta[2])
                        self.buscarCaminho(self.N.index(aresta[1] if aresta[1] != self.N[v] else aresta[2]))
                    elif self.grauMatriz(aresta[1] if aresta[1] != self.N[v] else aresta[2], self._matriz) != 0:
                        self._arestas.remove(aresta[0])
                        self._caminho.append(aresta[0])
                        self._caminho.append(aresta[1] if aresta[1] != self.N[v] else aresta[2])
                        self.buscarCaminho(self.N.index(aresta[1] if aresta[1] != self.N[v] else aresta[2]))

                    else:
                        self._matriz[linha][coluna] = aresta
                        self._arestas.append(aresta[0])
                        __N.append(self.N[v])
        return False

    def ponte(self, N):
        '''
        Verifica se determinado vertice é uma ponte dentro do grafo.
        :return: bool representando se é ponte
        '''
        l = list()
        for linha in self._matriz:
            for coluna in linha:
                if coluna != "-" and coluna != {}:
                    l.append(coluna[1])
                    l.append(coluna[2])
        for vertice in N:
            if not (vertice in l):
                return True
        return False

    def getAresta(self):
        '''
        Prove uma lista com as arestas do grafo.
        Lista do tipo [A0,A1,...,An]
        :return: lista.
        '''
        la = list()
        for lin in range(len(self.M)):
            for col in range(len(self.M)):
                if self.M[lin][col] != "-" and self.M[lin][col] != {}:
                    for aresta in self.M[lin][col]:
                        la.append(aresta)
        return la

    def grauMatriz(self, V, M):
        '''
        Provê o grau do vértice passado como parâmetro
        :param V: O rótulo do vértice a ser analisado
        :param M: Matriz a analisada a partir de V
        :return: Um valor inteiro que indica o grau do vértice
        :raises: VerticeInvalidoException se o vértice não existe no grafo
        '''
        if V not in self.N:
            raise VerticeInvalidoException
        cont = 0
        for l in range(len(M)):
            for c in range(len(M)):
                if M[l][c] != "-" and V in M[l][c]:
                    cont += 1
        return cont

    def matrizArestas(self):
        '''
        Prove uma matriz com as arestas do grafo.
        :return: Matriz com as arestas do grafo
        '''
        matriz = []
        for l in range(len(self.M)):
            matriz.append([])
            for c in range(len(self.M)):
                if self.M[l][c] != "-" and self.M[l][c] != {}:
                    for aresta in self.M[l][c]:
                        matriz[l].append([aresta, self.M[l][c][aresta].getV1(), self.M[l][c][aresta].getV2()])
                else:
                    matriz[l].append("-")
        return matriz

